#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "config.h"
#include "d3plotreaderwrapperc.h"

int main()
{
    int i = 0;
    char d3plot_file[1024];
	char title[40];
    char* handle;
    int ns = 0, nn = 0, nsh = 0;
    int* nodal_ids = NULL;
    _D3P_Vector* coords = NULL;
    _D3P_VectorDouble* dcoords = NULL;
    _D3P_Shell* shell_conn = NULL;
    _D3P_Tensor * shell_stress = NULL;
	float* shell_history_var = NULL;
    _D3P_Parameter dp;
    memset(&dp, 0, sizeof(_D3P_Parameter));

    strcpy(d3plot_file, DATA_PATH);
    
#ifdef WIN32		
    for(i=0; i<strlen(d3plot_file); i++) {
        if(d3plot_file[i] == '/') {
            d3plot_file[i] = '\\';
        }
    }
#else
    for(i=0; i<strlen(d3plot_file); i++) {
        if(d3plot_file[i] == '\\') {
            d3plot_file[i] = '/';
        }
    }
#endif
    
	handle = D3P_Open(d3plot_file);
	
	D3P_Read(handle, D3P_TITLE, (char*)title, dp);
	i = 0;
	printf("title: ");
	for(i=0;i<strlen(title);i++)
	{
		printf("%c", title[i]);
	}
	printf("\n");

    D3P_Read(handle, D3P_NUM_STATES, (char*)&ns, dp);
    printf("num states: %d\n", ns);

    
    D3P_Read(handle, D3P_NUM_NODES, (char*)&nn, dp);
    printf("num nodes: %d\n", nn);

    nodal_ids = (int*) malloc ( nn * sizeof(int) );
	D3P_Read(handle, D3P_NODE_IDS, (char*)nodal_ids, dp);

    D3P_Read(handle, D3P_NUM_SHELL, (char*)&nsh, dp);
    printf("num shells: %d\n", nsh);

	shell_conn = (_D3P_Shell*) malloc ( nsh * sizeof(_D3P_Shell) );
	D3P_Read(handle, D3P_SHELL_CONNECTIVITY_MAT, (char*)shell_conn, dp);
	printf("shell_conn[0](%d, %d, %d, %d)\n", nodal_ids[shell_conn[0].conn[0]-1], nodal_ids[shell_conn[0].conn[1]-1], nodal_ids[shell_conn[0].conn[2]-1], nodal_ids[shell_conn[0].conn[3]-1]);
	free(shell_conn);
	free(nodal_ids);

    coords = (_D3P_Vector*) malloc ( nn * sizeof(_D3P_Vector) );
    D3P_Read(handle, D3P_NODE_COORDINATES, (char*)coords, dp);
    printf("coords[211](%f, %f, %f) at the first state\n", coords[211].v[0], coords[211].v[1], coords[211].v[2]);

    dp.ist = 11;
    D3P_Read(handle, D3P_NODE_COORDINATES, (char*)coords, dp);
    printf("coords[211](%.10f, %.10f, %.10f) at the last state\n", coords[211].v[0], coords[211].v[1], coords[211].v[2]);
    free(coords);

    dcoords = (_D3P_VectorDouble*) malloc ( nn * sizeof(_D3P_VectorDouble) );
    D3P_Read(handle, D3P_NODE_COORDINATES_DOUBLE, (char*)dcoords, dp);
    printf("coords[211](%.10f, %.10f, %.10f) at the last state\n", dcoords[211].v[0], dcoords[211].v[1], dcoords[211].v[2]);

    dp.ipt = 2;
    shell_stress = (_D3P_Tensor*) malloc ( nsh * sizeof(_D3P_Tensor) );
	D3P_Read(handle, D3P_SHELL_STRESS, (char*)shell_stress, dp);
	printf("shell_stress[0](%f, %f, %f, %f, %f, %f)\n", shell_stress[0].t[0], shell_stress[0].t[1], shell_stress[0].t[2], shell_stress[0].t[3], shell_stress[0].t[4], shell_stress[0].t[5]);
	free(shell_stress);

	dp.ist = 0;
	dp.ipt = 0;
	dp.ihv = 1;
	shell_history_var = (float*)malloc(nsh *sizeof(float));
	D3P_Read(handle, D3P_SHELL_HISTORY_VAR, (char*)shell_history_var,dp);
	printf("shell_history_var[0]: %f\n", shell_history_var[0]);
	free(shell_history_var);

    D3P_Close(handle);

#ifdef WIN32
	system("pause");
#endif
}