Lsreader
********

Introduction
============

Supported Languages
-------------------

* C++
* C
* Python(>=3.4.10)

Supported Platforms
-------------------

* Microsoft Windows(vs2010, vs2015, vs2017)
* Linux(gcc>=4.4.7)

Tree
---------

├── CMakeLists.txt
├── README.txt
├── config.h.in             #data_path(c++ and c)
├── d3plotreadercxxdist
│   ├── CMakeLists.txt
│   ├── d3plotreader.h
│   ├── lib
│   │   ├── linux
│   │   │   ├── libd3plotreader_cxx_0.0.1.tar.gz 
│   │   ├── vs2010
│   │   │   ├── d3plotreader_cxx-vc100-0_1.dll
│   │   │   └── d3plotreader_cxx-vc100-0_1.lib
│   │   ├── vs2015
│   │   │   ├── d3plotreader_cxx-vc140-0_1.dll
│   │   │   └── d3plotreader_cxx-vc140-0_1.lib
│   │   └── vs2017
│   │       ├── d3plotreader_cxx-vc141-0_1.dll
│   │       └── d3plotreader_cxx-vc141-0_1.lib
│   └── example.cpp
├── d3plotreaderwrappercdist
│   ├── CMakeLists.txt
│   ├── d3plotreaderwrapperc.h
│   ├── lib
│   │   ├── linux
│   │   │   └── libd3plotreader_c_0.0.1.tar.gz
│   │   ├── vs2010
│   │   │   ├── d3plotreader_c-vc100-0_1.dll
│   │   │   └── d3plotreader_c-vc100-0_1.lib
│   │   ├── vs2015
│   │   │   ├── d3plotreader_c-vc140-0_1.dll
│   │   │   └── d3plotreader_c-vc140-0_1.lib
│   │   └── vs2017
│   │       ├── d3plotreader_c-vc141-0_1.dll
│   │       └── d3plotreader_c-vc141-0_1.lib
│   └── example.c
├── d3plotreaderwrapperpythondist
│   ├── CMakeLists.txt
│   ├── lib
│   │   ├── linux
│   │   │   ├── libd3plotreader_python_0.0.1.tar.gz
│   │   └── windows
│   │       └── lsreader.pyd
│   ├── lsreader.pyd
│   └── example.py
├── example_data
└── documents
    └── tutorial.pdf

Building Test
=============

Windows
-------
You need to use CMake(>=2.6) in order to build test for C++ and C and use the Python interpreter(>=3.6.0) to build test for python.

Linux
-----
You alse need to use CMake(>=2.6) and the Python interpreter(>=3.4.10). 
