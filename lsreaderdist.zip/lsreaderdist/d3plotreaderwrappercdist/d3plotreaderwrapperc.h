#ifndef __D3PLOT_READER_WRAPPER_C_H__
#define __D3PLOT_READER_WRAPPER_C_H__

#ifdef WIN32
#if defined (D3PLOTREADERWRAPPERC_STATIC_LIB)
#define CREADERAPI
#else
#if defined (d3plotreader_c_EXPORTS)
#define CREADERAPI __declspec(dllexport)
#else // outside DLL
#define CREADERAPI __declspec(dllimport)
#endif
#endif

#else
#define CREADERAPI
#endif

#ifndef __DATA_TYPE_ENUMERATIONS__
#define __DATA_TYPE_ENUMERATIONS__
enum D3P_DataType
{
	D3P_TITLE,
	/**
	 *conversion: char[]
	 *parameters: ignore
	 */

	//STATE BLOCK
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ignore
	 */
	D3P_NUM_STATES,
	/**
	 * conversion: float
	 * length    : D3P_NUM_STATES
	 * parameters: ignore
	 */
	D3P_TIMES,
	/**
	 * conversion: float
	 * length    : 1
	 * parameters: ist
	 */
	D3P_GLOBAL_KINETIC_ENERGY,
	/**
	 * conversion: float
	 * length    : 1
	 * parameters: ist
	 */
	D3P_GLOBAL_INTERNAL_ENERGY,
	/**
	 * conversion: float
	 * length    : 1
	 * parameters: ist
	 */
	D3P_GLOBAL_TOTAL_ENERGY,
	/**
	 * conversion: D3P_Vector
	 * length    : 1
	 * parameters: ist
	 */
	D3P_GLOBAL_VELOCITY,
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ist
	 */
	D3P_NEW_GEOM,


	//PART
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ignore
	 */
	D3P_NUM_PARTS,	
	/**
	 * conversion: int
	 * length    : D3P_NUM_PARTS
	 * parameters: ignore
	 */
	D3P_PART_IDS,	
    /**
	 * conversion: char
	 * length    : 80
	 * parameters: ipart
	 */
	D3P_PART_NAME,
	/**
	 * conversion: float
	 * length    : 1
	 * parameters: ist, ipart
	 */
	D3P_PART_INTERNAL_ENERGY,
	/**
	 * conversion: float
	 * length    : 1
	 * parameters: ist, ipart
	 */
	D3P_PART_KINETIC_ENERGY,
	/**
	 * conversion: D3P_Vector
	 * length    : 1
	 * parameters: ist, ipart
	 */
	D3P_PART_VELOCITY,
	/**
	 * conversion: float
	 * length    : 1
	 * parameters: ist, ipart
	 */
	D3P_PART_MASS,
	/**
	 * conversion: float
	 * length    : 1
	 * parameters: ist, ipart
	 */
	D3P_PART_HOURGLASS,

	//RIGID WALL
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ignore
	 */
	D3P_NUM_RIGID_WALL,
	/**
	 * conversion: float
	 * length    : 1
	 * parameters: ist, i_rigid_wall
	 */
	D3P_RIGID_WALL_FORCE,
	/**
	 * conversion: D3P_Vector
	 * length    : 1
	 * parameters: ist, i_rigid_wall
	 */
	D3P_RIGID_WALL_POSITION,
		
	//NODE
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ignore
	 */
	D3P_NUM_NODES,
	/**
	 * conversion: D3P_Vector
	 * length    : D3P_NUM_NODES
	 * parameters: ignore
	 */
	D3P_NODE_INITIAL_COORDINATES,
	/**
	 * conversion: int
	 * length    : D3P_NUM_NODES
	 * parameters: ignore
	 */
	D3P_NODE_IDS,
	/**
	 * conversion: float
	 * length    : D3P_NUM_NODES
	 * parameters: ist
	 */
	D3P_NODE_TEMPERATURE,
	/**
	 * conversion: D3P_Vector
	 * length    : D3P_NUM_NODES
	 * parameters: ist
	 */
	D3P_NODE_COORDINATES,
	/**
	 * conversion: D3P_Vector
	 * length    : D3P_NUM_NODES
	 * parameters: ist
	 */
	D3P_NODE_VELOCITIES,
	/**
	 * conversion: D3P_Vector
	 * length    : D3P_NUM_NODES
	 * parameters: ist
	 */
	D3P_NODE_ACCELERATIONS,
    /**
	 * conversion: D3P_VectorDouble
	 * length    : D3P_NUM_NODES
	 * parameters: ist
	 */
	D3P_NODE_COORDINATES_DOUBLE,
	/**
	 * conversion: D3P_VectorDouble
	 * length    : D3P_NUM_NODES
	 * parameters: ist
	 */
	D3P_NODE_VELOCITIES_DOUBLE,
	/**
	 * conversion: D3P_VectorDouble
	 * length    : D3P_NUM_NODES
	 * parameters: ist
	 */
	D3P_NODE_ACCELERATIONS_DOUBLE,
	
	//SOLID
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ignore
	 */
	D3P_NUM_SOLID,
	/**
	 * conversion: D3P_Solid
	 * length    : D3P_NUM_SOLID
	 * parameters: ignore
	 */
	D3P_SOLID_CONNECTIVITY_MAT,
	/**
	 * conversion: int
	 * length    : D3P_NUM_SOLID
	 * parameters: ignore
	 */
	D3P_SOLID_IDS,
	/**
	 * conversion: D3P_Tensor
	 * length    : D3P_NUM_SOLID
	 * parameters: ist, ipt if necessary
	 */
	D3P_SOLID_STRESS,
	/**
	 * conversion: float
	 * length    : D3P_NUM_SOLID
	 * parameters: ist, ipt if necessary
	 */
	D3P_SOLID_EFFECTIVE_PLASTIC_STRAIN,
	/**
	 * conversion: D3P_Tensor
	 * length    : D3P_NUM_SOLID
	 * parameters: ist, ipt if necessary
	 */
	D3P_SOLID_STRAIN,
	/**
	* conversion: float
	* length    : D3P_NUM_SOLID
	* parameters: ist, ipt, ihv
	*/
	D3P_SOLID_HISTORY_VAR, 
	/**
	* conversion: int
	* length    : 1
	* parameters: ignore
	*/
	D3P_SOLID_MAXINT,
	
	//TSHELL
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ignore
	 */
	D3P_NUM_TSHELL,
	/**
	 * conversion: D3P_Tshell
	 * length    : D3P_NUM_TSHELL
	 * parameters: ignore
	 */
	D3P_TSHELL_CONNECTIVITY_MAT, 
	/**
	 * conversion: int
	 * length    : D3P_NUM_TSHELL
	 * parameters: ignore
	 */
	D3P_TSHELL_IDS,
	/**
	 * conversion: D3P_Tensor
	 * length    : D3P_NUM_TSHELL
	 * parameters: ist, ipt
	 */
	D3P_TSHELL_STRESS,
	/**
	 * conversion: float
	 * length    : D3P_NUM_TSHELL
	 * parameters: ist, ipt
	 */
	D3P_TSHELL_EFFECTIVE_PLASTIC_STRAIN,
	/**
	 * conversion: D3P_Tensor
	 * length    : D3P_NUM_TSHELL
	 * parameters: ist, ipt
	 */
	D3P_TSHELL_STRAIN,
	/**
	* conversion: float
	* length    : D3P_NUM_TSHELL
	* parameters: ist, ipt, ihv
	*/
	D3P_TSHELL_HISTORY_VAR,
	/**
	* conversion: int
	* length    : 1
	* parameters: ignore
	*/
	D3P_TSHELL_MAXINT,



	
	//BEAM
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ignore
	 */
	D3P_NUM_BEAM,
	/**
	 * conversion: D3P_Beam
	 * length    : D3P_NUM_BEAM
	 * parameters: ignore
	 */
	D3P_BEAM_CONNECTIVITY_THIRD_MAT,
	/**
	 * conversion: int
	 * length    : D3P_NUM_BEAM
	 * parameters: ignore
	 */
	D3P_BEAM_IDS,
	/**
	 * conversion: float
	 * length    : D3P_NUM_BEAM
	 * parameters: ist
	 */
	D3P_BEAM_AXIAL_FORCE,
	/**
	 * conversion: float
	 * length    : D3P_NUM_BEAM
	 * parameters: ist
	 */
	D3P_BEAM_S_SHEAR_RESULTANT,
	/**
	 * conversion: float
	 * length    : D3P_NUM_BEAM
	 * parameters: ist
	 */
	D3P_BEAM_T_SHEAR_RESULTANT,
	/**
	 * conversion: float
	 * length    : D3P_NUM_BEAM
	 * parameters: ist
	 */
	D3P_BEAM_S_BENDING_MOMENT,
	/**
	 * conversion: float
	 * length    : D3P_NUM_BEAM
	 * parameters: ist
	 */
	D3P_BEAM_T_BENDING_MOMENT,
	/**
	 * conversion: float
	 * length    : D3P_NUM_BEAM
	 * parameters: ist
	 */
	D3P_BEAM_TORSIONAL_RESULTANT,
	/**
	 * conversion: float
	 * length    : D3P_NUM_BEAM
	 * parameters: ist, ipt
	 */
	D3P_BEAM_AXIAL_STRESS,
	/**
	 * conversion: float
	 * length    : D3P_NUM_BEAM
	 * parameters: ist, ipt
	 */
	D3P_BEAM_RS_SHEAR_STRESS, 
	/**
	 * conversion: float
	 * length    : D3P_NUM_BEAM
	 * parameters: ist, ipt
	 */
	D3P_BEAM_TR_SHEAR_STRESS, 
	/**
	 * conversion: float
	 * length    : D3P_NUM_BEAM
	 * parameters: ist, ipt
	 */
	D3P_BEAM_AXIAL_PLASTIC_STRAIN,
	/**
	 * conversion: float
	 * length    : D3P_NUM_BEAM
	 * parameters: ist, ipt
	 */
	D3P_BEAM_AXIAL_STRAIN,
	/**
	* conversion: float
	* length    : D3P_NUM_BEAM
	* parameters: ist, ipt, ihv
	*/
	D3P_BEAM_HISTORY_VAR,
	/**
	* conversion: int
	* length    : 1
	* parameters: ignore
	*/
	D3P_BEAM_MAXINT,




	//SHELL
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ignore
	 */
	D3P_NUM_SHELL,
	/**
	 * conversion: D3P_Shell
	 * length    : D3P_NUM_SHELL
	 * parameters: ignore
	 */
	D3P_SHELL_CONNECTIVITY_MAT,
	/**
	 * conversion: int
	 * length    : D3P_NUM_SHELL
	 * parameters: ignore
	 */
	D3P_SHELL_IDS,
	/**
	 * conversion: D3P_Tensor
	 * length    : D3P_NUM_SHELL
	 * parameters: ist, ipt
	 */
	D3P_SHELL_STRESS,
	/**
	 * conversion: float
	 * length    : D3P_NUM_SHELL
	 * parameters: ist, ipt
	 */
	D3P_SHELL_EFFECTIVE_PLASTIC_STRAIN,
	/**
	 * conversion: D3P_Tensor
	 * length    : D3P_NUM_SHELL
	 * parameters: ist, ipt
	 */
	D3P_SHELL_STRAIN,
	/**
	* conversion: float
	* length    : D3P_NUM_SHELL
	* parameters: ist
	*/
	D3P_SHELL_THICKNESS,
	/**
	* conversion: float
	* length    : D3P_NUM_SHELL
	* parameters: ist, ipt, ihv
	*/
	D3P_SHELL_HISTORY_VAR,
	/**
	* conversion: int
	* length    : 1
	* parameters: ignore
	*/
	D3P_SHELL_MAXINT,
	/**
	* conversion: float
	* length    : D3P_NUM_SHELL
	* parameters: ist
	*/
	D3P_SHELL_MX,
	/**
	* conversion: float
	* length    : D3P_NUM_SHELL
	* parameters: ist
	*/
	D3P_SHELL_MY,
	/**
	* conversion: float
	* length    : D3P_NUM_SHELL
	* parameters: ist
	*/
	D3P_SHELL_MXY,
	/**
	* conversion: float
	* length    : D3P_NUM_SHELL
	* parameters: ist
	*/
	D3P_SHELL_QX,
	/**
	* conversion: float
	* length    : D3P_NUM_SHELL
	* parameters: ist
	*/
	D3P_SHELL_QY,
	/**
	* conversion: float
	* length    : D3P_NUM_SHELL
	* parameters: ist
	*/
	D3P_SHELL_NX,
	/**
	* conversion: float
	* length    : D3P_NUM_SHELL
	* parameters: ist
	*/
	D3P_SHELL_NY,
	/**
	* conversion: float
	* length    : D3P_NUM_SHELL
	* parameters: ist
	*/
	D3P_SHELL_NXY,
	/**
	* conversion: float
	* length    : D3P_NUM_SHELL
	* parameters: ist
	*/
	D3P_SHELL_INTERNAL_ENERGY_DENSITY,

	//DELETION
    /**
     * conversion: bool
     * length    : 1
     * parameters: ist
     */
    D3P_HAS_DELETION,
	/**
	* conversion: float
	* length    : D3P_NUM_SOLID + D3P_NUM_TSHELL + D3P_NUM_SHELL + D3P_NUM_BEAM
	* parameters: ist
	*/
	D3P_ALL_DELETION,
    /**
     * conversion: float
     * length    : D3P_NUM_SOLID
     * parameters: ist
     */
    D3P_SOLID_DELETION,
    /**
     * conversion: float
     * length    : D3P_NUM_TSHELL
     * parameters: ist
     */
    D3P_TSHELL_DELETION,
	/**
	 * conversion: float
	 * length    : D3P_NUM_SHELL
	 * parameters: ist
	 */
	D3P_SHELL_DELETION,
    /**
     * conversion: float
     * length    : D3P_NUM_BEAM
     * parameters: ist
     */
    D3P_BEAM_DELETION,
	//SPH
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ignore
	 */
	D3P_NUM_SPH,
	/**
	 * conversion: D3P_Sph
	 * length    : D3P_NUM_SPH
	 * parameters: ignore
	 */
	D3P_SPH_NODE_MAT,
	/**
	 * conversion: float
	 * length    : D3P_NUM_SPH
	 * parameters: ist
	 */
	D3P_SPH_RADIUS,
	/**
	 * conversion: float
	 * length    : D3P_NUM_SPH
	 * parameters: ist
	 */
	D3P_SPH_PRESSURE,
	/**
	 * conversion: D3P_Tensor
	 * length    : D3P_NUM_SPH
	 * parameters: ist
	 */
	D3P_SPH_STRESS,
	/**
	 * conversion: float
	 * length    : D3P_NUM_SPH
	 * parameters: ist
	 */
	D3P_SPH_PLASTIC_STRAIN,
	/**
	 * conversion: float
	 * length    : D3P_NUM_SPH
	 * parameters: ist
	 */
	D3P_SPH_DENSITY, 
	/**
	 * conversion: float
	 * length    : D3P_NUM_SPH
	 * parameters: ist
	 */
	D3P_SPH_INTERNAL_ENERGY,
	/**
	 * conversion: int
	 * length    : D3P_NUM_SPH
	 * parameters: ist
	 */
	D3P_SPH_NUMBER_OF_PARTICLE_NEIGHBORS,
	/**
	 * conversion: D3P_Tensor
	 * length    : D3P_NUM_SPH
	 * parameters: ist
	 */
	D3P_SPH_STRAIN,
	/**
	 * conversion: float
	 * length    : D3P_NUM_SPH
	 * parameters: ist
	 */
	D3P_SPH_MASS,

	//DES
	/**
	 * conversion: bool
	 * length    : 1
	 * parameters: ignore
	 */
	D3P_HAS_DES_DATA,
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ignore
	 */
	D3P_NUM_DES_DATA,
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ides if necessary
	 */
	D3P_NUM_DES_PART_IN_GEOM,
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ides if necessary
	 */
	D3P_NUM_DES_ELEM_IN_GEOM,
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ides if necessary
	 */
	D3P_NUM_DES_PART_IN_STATE,
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ides if necessary
	 */
	D3P_NUM_DES_ELEM_IN_STATE,
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ides if necessary
	 */
	D3P_NUM_DES_PART_VAR_IN_GEOM,
	/**
	 * conversion: D3P_VAR
	 * length    : D3P_NUM_DES_PART_VAR_IN_GEOM
	 * parameters: ides if necessary
	 */
	D3P_DES_PART_VAR_LIST_IN_GEOM,
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ides if necessary
	 */
	D3P_NUM_DES_ELEM_VAR_IN_GEOM,
	/**
	 * conversion: D3P_VAR
	 * length    : D3P_NUM_DES_ELEM_VAR_IN_GEOM
	 * parameters: ides if necessary
	 */
	D3P_DES_ELEM_VAR_LIST_IN_GEOM,
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ides if necessary
	 */
	D3P_NUM_DES_PART_VAR_IN_STATE,
	/**
	 * conversion: D3P_VAR
	 * length    : D3P_NUM_DES_PART_VAR_IN_STATE
	 * parameters: ides if necessary
	 */
	D3P_DES_PART_VAR_LIST_IN_STATE,
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ides if necessary
	 */
	D3P_NUM_DES_ELEM_VAR_IN_STATE,
	/**
	 * conversion: D3P_VAR
	 * length    : D3P_NUM_DES_ELEM_VAR_IN_STATE
	 * parameters: ides if necessary
	 */
	D3P_DES_ELEM_VAR_LIST_IN_STATE,
	/**
	 * conversion: D3P_DES
	 * length    : D3P_NUM_DES_ELEM_IN_GEOM
	 * parameters: ides if necessary
	 */
	D3P_DES_NODAL_MAT_RADIUS_MASS_INERTIA,
	/**
	 * conversion: int/float/vector/tensor..depends
	 * length    : D3P_NUM_DES_ELEM_IN_STATE
	 * parameters: var_name, ist, ides if necessary
	 */
	D3P_DES_DATA_IN_STATE,

	//CPM
	/**
	 * conversion: bool
	 * length    : 1
	 * parameters: ignore
	 */
	D3P_HAS_CPM_DATA,
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ignore
	 */
	D3P_CPM_NUM_AIRBAGS,
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ignore
	 */
	D3P_CPM_NUM_PARTICLES,
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ignore
	 */
	D3P_CPM_NUM_GEOM_VAR,
	/**
	 * conversion: D3P_VAR
	 * length    : D3P_CPM_NUM_GEOM_VAR
	 * parameters: ignore
	 */
	D3P_CPM_GEOM_VAR_LIST,
	/**
	 * conversion: int/float...depends
	 * length    : D3P_CPM_NUM_AIRBAGS
	 * parameters: var_name
	 */
	D3P_CPM_GEOM_DATA,
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ignore
	 */
	D3P_CPM_NUM_STATE_VAR, 
	/**
	 * conversion: D3P_VAR
	 * length    : D3P_CPM_NUM_STATE_VAR
	 * parameters: ignore
	 */
	D3P_CPM_STATE_VAR_LIST,
	/**
	 * conversion: int/float...depends
	 * length    : D3P_CPM_NUM_PARTICLES
	 * parameters: var_name, ist
	 */
	D3P_CPM_STATE_DATA,
	/**
	 * conversion: int
	 * length    : 1
	 * parameters: ignore
	 */
	D3P_CPM_NUM_STATE_GEOM_VAR,
	/**
	 * conversion: D3P_VAR
	 * length    : D3P_CPM_NUM_STATE_GEOM_VAR
	 * parameters: ignore
	 */
	D3P_CPM_STATE_GEOM_VAR_LIST,
	/**
	 * conversion: int/float...depends
	 * length    : D3P_CPM_NUM_AIRBAGS
	 * parameters: var_name, ist
	 */
	D3P_CPM_STATE_GEOM_DATA,	
};
#endif

typedef struct _D3P_Vector_
{
	float v[3];
} _D3P_Vector;

typedef struct D3P_VectorDouble_
{
	double v[3];
} _D3P_VectorDouble;

typedef struct _D3P_Tensor_
{
	float t[6];
} _D3P_Tensor;

typedef struct _D3P_Solid_
{
	int conn[10];
	int mat;
} _D3P_Solid;

typedef struct _D3P_Tshell_
{
	int conn[10];
	int mat;
} _D3P_Tshell;

typedef struct _D3P_Beam_
{ 
	int conn[2];
	int third;
	int w_int; 
	int h_int;
	int mat; 
} _D3P_Beam;

typedef struct _D3P_Shell_
{
	int conn[4];
	int mat;
} _D3P_Shell;

typedef struct _D3P_Sph
{ 
	int id;
	unsigned int mat;
} _D3P_Sph;

typedef struct _D3P_Var_
{
    int type;
    char name[8];
} _D3P_Var;

typedef struct _D3P_Des_
{
	int id;
	int mat;
	float radius;
	float mass;
	float inertia;
} _D3P_Des;

typedef struct _D3P_AirbagInfo_
{
	int bagid;
	int startn;
	int npart;
	int ngas;
	int nchamber;
} _D3P_AirbagInfo;

/**
 * parameter to call D3plotReader::GetData, only specific those member variables you are interesting, otherwise, ignore this
 */
typedef struct _D3P_Parameter_
{
	/**
	 * the state number, start from 0 and default is 0 also
	 */
	int ist; 
	/**
	 * the integration point, range in [0, MAXINT), and default is 0
	 */
	int ipt;
	/**
	 * the index of part, start from 0 and default is 0 also
	 */
	int ipart;
	/**
	 * the index of rigid wall, start from 0 and default is 0 also
	 */
	int i_rigid_wall;
	/**
	 * the index of the des data, start from 0 and default is 0 also
	 */
	int ides; 
	/**
	 * the index of history variables, start from 0(sequence number)
	 */
	int ihv;
	/**
	 * name of output variables, currently used by DES and CPM data, default is empty
	 */
	char var_name[8];
} _D3P_Parameter;

#ifdef __cplusplus
extern "C"
{
#endif

CREADERAPI char* D3P_Open (const char* filename);
CREADERAPI int   D3P_Read (char* handle, enum D3P_DataType type, char* value, _D3P_Parameter param);
CREADERAPI void  D3P_Close(char* handle);

#ifdef __cplusplus
}
#endif

#endif
