#include <string.h>
#include <iostream>
#include <vector>

#include "config.h"
#include "d3plotreader.h"
using namespace std;

int main()
{
	string d3plot_file = DATA_PATH;

#ifdef WIN32
    string::size_type pos = d3plot_file.find('/');
	while(pos != string::npos)
	{
		d3plot_file.replace(pos, 1, "\\");
		pos = d3plot_file.find('/');
	}
#else
	 string::size_type pos = d3plot_file.find('\\');
	while(pos != string::npos)
	{
		d3plot_file.replace(pos, 1, "/");
		pos = d3plot_file.find('\\');
	}
#endif
    
	D3plotReader dr(d3plot_file.c_str());
	
	char title[40];
	dr.GetData(D3P_TITLE, (char*)title);
	cout<<"title: "<<title<<endl;
	
	int num_states = 0;
	dr.GetData(D3P_NUM_STATES, (char*)&num_states);
	cout<<"num states: "<<num_states<<endl;
	
	int num_nodes = 0;
	dr.GetData(D3P_NUM_NODES, (char*)&num_nodes);
	cout<<"num nodes: "<<num_nodes<<endl;
	
	int* nodal_ids = new int[num_nodes];
	dr.GetData(D3P_NODE_IDS, (char*)nodal_ids);
	
	int num_shell_elements = 0;
	dr.GetData(D3P_NUM_SHELL, (char*)&num_shell_elements);
	cout<<"num shells: "<<num_shell_elements<<endl;
	
	D3P_Shell* shells = new D3P_Shell[num_shell_elements];
	dr.GetData(D3P_SHELL_CONNECTIVITY_MAT, (char*)shells);
	cout<<"shell_conn[0]("<<nodal_ids[shells[0].conn[0]-1]<<", "<<nodal_ids[shells[0].conn[1]-1]<<", "<<nodal_ids[shells[0].conn[2]-1]<<", "<<nodal_ids[shells[0].conn[3]-1]<<")"<<endl;
	delete[] shells;
	delete[] nodal_ids;
	
	D3P_Parameter param;
	
	param.ist = 11;
	D3P_Vector* coords = new D3P_Vector[num_nodes];
	dr.GetData(D3P_NODE_COORDINATES, (char*)coords, param);
	cout.precision(6);
	cout<<fixed;
	cout<<"coords[211]("<<coords[211].v[0]<<", "<<coords[211].v[1]<<", "<<coords[211].v[2]<<") at the first state"<<endl;
	
	param.ist = 11;
	dr.GetData(D3P_NODE_COORDINATES, (char*)coords, param);
	cout.precision(10);
	cout<<"coords[211]("<<coords[211].v[0]<<", "<<coords[211].v[1]<<", "<<coords[211].v[2]<<") at the last state"<<endl;
	delete[] coords;
	
	D3P_VectorDouble* dcoords = new D3P_VectorDouble[num_nodes];
	dr.GetData(D3P_NODE_COORDINATES_DOUBLE, (char*)dcoords, param);
	cout<<"dcoords[211]("<<dcoords[211].v[0]<<", "<<dcoords[211].v[1]<<", "<<dcoords[211].v[2]<<") at the last state"<<endl;
	delete[] dcoords;
	
	D3P_Tensor* shell_stress = new D3P_Tensor[num_shell_elements];
	param.ipt = 2;
	dr.GetData(D3P_SHELL_STRESS, (char*)shell_stress, param);
	cout.precision(6);
	cout<<"shell_stress[0]("<<shell_stress[0].t[0]<<", "<<shell_stress[0].t[1]<<", "<<shell_stress[0].t[2]<<", "<<shell_stress[0].t[3]<<", "<<shell_stress[0].t[4]<<", "<<shell_stress[0].t[5]<<")"<<endl;
	delete[] shell_stress;

	float* shell_history_var = new float[num_shell_elements];
	param.ist = 0;
	param.ipt = 0;
	param.ihv = 1;
	dr.GetData(D3P_SHELL_HISTORY_VAR, (char*)shell_history_var, param);
	cout<<"shell_history_var[0]: "<<shell_history_var[0]<<"\n"<<endl;
	delete[] shell_history_var;
	

#ifdef WIN32
	system("pause");
#endif

}